<?php
// Database connection
$host = "localhost";
$port = "5432";
$dbname = "lms_database";
$user = "postgres";
$password = "191217Azena";

// Connect to the PostgreSQL database
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Error: Unable to connect to the database.");
}

// Debugging: Check if the form was submitted and print the POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "Form submitted successfully!<br>";

    // Debug: Show all posted data to see if everything is coming through
    echo "POST Data: <pre>";
    print_r($_POST);
    echo "</pre>";

    // Collect form data safely
    $title = isset($_POST['title']) ? $_POST['title'] : '';
    $author = isset($_POST['author']) ? trim($_POST['author']) : '';  // Trim spaces
    $publisher = isset($_POST['publisher']) ? $_POST['publisher'] : '';
    $publish_date = isset($_POST['publish_date']) ? $_POST['publish_date'] : '';
    $category_id = isset($_POST['category_id']) ? $_POST['category_id'] : '';

    // Check for missing fields
    if (empty($title) || empty($author) || empty($publisher) || empty($publish_date) || empty($category_id)) {
        echo "Please fill in all fields.";
        exit;
    }

    // Extract year from the publish_date (assuming the format is 'YYYY-MM-DD')
    $year_of_publication = substr($publish_date, 0, 4);  // Get the first 4 characters for the year

    // Get the author ID from the Authors table
    $query = "SELECT AuthorsID FROM Authors WHERE LOWER(Name) = LOWER($1)";
    $result = pg_query_params($conn, $query, array($author));

    // Check if the author exists
    if ($result && pg_num_rows($result) > 0) {
        $author_id = pg_fetch_result($result, 0, 'AuthorsID');
    } else {
        echo "Author not found!";
        exit; // Exit if author doesn't exist
    }

    // Prepare and execute the INSERT statement (with publisher and correct year)
    $query = "INSERT INTO Books (Title, Publisher, YearOfPublication, AuthorID, CategoryID) 
              VALUES ($1, $2, $3, $4, $5)";
    $result = pg_query_params($conn, $query, array($title, $publisher, $year_of_publication, $author_id, $category_id));

    // Check if the book was successfully added
    if ($result) {
        echo "Book added successfully!";
    } else {
        echo "Error in adding book: " . pg_last_error($conn);
    }
} else {
    echo "Form not submitted correctly.";
}

// Close the connection
pg_close($conn);
?>
