<?php
$host = "localhost"; // The host (usually 'localhost' for local setups)
$port = "5432"; // Default PostgreSQL port
$dbname = "lms_database"; // Your database name
$user = "postgres"; // Default PostgreSQL user
$password = "191217Azena"; // The password you set during PostgreSQL installation

// Create a connection to PostgreSQL
$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Check if the connection was successful
if (!$conn) {
    echo "Error: Unable to connect to the database.\n";
} else {
    echo "Connected to the database.\n";
}
?>
