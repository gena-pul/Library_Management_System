<?php
// Enable error reporting to display any PHP errors
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection credentials
$host = "localhost";            // Database host
$dbname = "lms_database";       // Database name
$user = "postgres";             // Database user (default pgamin4 or postgres)
$password = "191217Azena";      // Database password

// Attempt to connect to PostgreSQL
$db_conn = pg_connect("host=$host dbname=$dbname user=$user password=$password");

// Check if the connection was successful
if (!$db_conn) {
    die("Connection failed: " . pg_last_error());  // Only call pg_last_error() after the connection is successful
}

// Query to get overdue books (where returnDate is NULL)
$query = "
    SELECT b.title, l.loanDate, l.dueDate
    FROM loans l
    JOIN books b ON l.bookid = b.bookid
    WHERE l.returnDate IS NULL;
";

$result = pg_query($db_conn, $query);

// Check if the query was successful
if (!$result) {
    echo "Error executing query: " . pg_last_error($db_conn);
} else {
    // Basic CSS for table lines and spacing
    echo "<style>
            table {
                width: 80%;
                margin: 20px auto;
                border-collapse: collapse; /* Keep table lines simple */
            }
            th, td {
                padding: 10px; /* Add spacing for clarity */
                text-align: left;
                border: 1px solid black; /* Plain black table lines */
            }
            h2 {
                text-align: center;
            }
        </style>";

    // Display the results in a table
    echo "<h2>Overdue Books Report</h2>";
    echo "<table>";
    echo "<tr><th>Book Title</th><th>Loan Date</th><th>Due Date</th></tr>";

    // Loop through the query results and display them
    while ($row = pg_fetch_assoc($result)) {
        $bookTitle = htmlspecialchars($row['title']);
        $loanDate = $row['loandate'];
        $dueDate = $row['duedate'];

        // Format the loanDate and dueDate for display
        $loanDateFormatted = date("F j, Y", strtotime($loanDate));
        $dueDateFormatted = date("F j, Y", strtotime($dueDate));

        echo "<tr>
                <td>$bookTitle</td>
                <td>$loanDateFormatted</td>
                <td>$dueDateFormatted</td>
              </tr>";
    }

    echo "</table>";
}

// Close the database connection
pg_close($db_conn);
?>
