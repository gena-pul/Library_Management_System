<?php
// Enable error reporting to display any PHP errors
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection using the credentials you provided
$db_conn = pg_connect("host=localhost dbname=lms_database user=postgres password=191217Azena");

if (!$db_conn) {
    // If the connection fails, display the error message and exit
    die("Connection failed: " . pg_last_error());
} else {
    // If connected, confirm the connection (optional, you can remove this echo for cleaner output)
    // echo "Connected to database.<br>";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if form data exists before using it to avoid undefined index warnings
    $patron_id = isset($_POST['patron_id']) ? $_POST['patron_id'] : '';  // Patron ID from the form
    $name = isset($_POST['name']) ? $_POST['name'] : '';  // Patron's name from the form
    $address = isset($_POST['address']) ? $_POST['address'] : '';  // Patron's address from the form
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';  // Patron's phone number from the form
    $email = isset($_POST['email']) ? $_POST['email'] : '';  // Patron's email from the form

    // If patron ID is provided, it's an update operation
    if (!empty($patron_id) && isset($_POST['action']) && $_POST['action'] === 'update') {
        // Prepare the SQL query to update the patron information
        $query = "
            UPDATE patrons
            SET 
                name = COALESCE(NULLIF($2, ''), patrons.name),  -- Update name only if it's not an empty string
                address = COALESCE(NULLIF($3, ''), patrons.address),  -- Update address only if it's not an empty string
                phone = COALESCE(NULLIF($4, ''), patrons.phone),  -- Update phone only if it's not an empty string
                email = COALESCE(NULLIF($5, ''), patrons.email)  -- Update email only if it's not an empty string
            WHERE patronsID = $1;
        ";

        // Execute the query with parameters bound to the placeholders
        $result = pg_query_params($db_conn, $query, array($patron_id, $name, $address, $phone, $email));

        // Check if the query was successful
        if ($result) {
            echo "Patron updated successfully.<br>";
        } else {
            echo "Error updating patron: " . pg_last_error($db_conn) . "<br>";
        }

    } elseif (!empty($patron_id) && isset($_POST['action']) && $_POST['action'] === 'delete') {
        // Deletion operation
        // Prepare the SQL query to delete the patron
        $query = "DELETE FROM patrons WHERE patronsID = $1";

        // Execute the query with parameters bound to the placeholders
        $result = pg_query_params($db_conn, $query, array($patron_id));

        // Check if the query was successful
        if ($result) {
            echo "Patron deleted successfully.<br>";
        } else {
            echo "Error deleting patron: " . pg_last_error($db_conn) . "<br>";
        }

    } else {
        // Add new patron if no patron ID is provided (this is for adding patrons)
        $query = "
            INSERT INTO patrons (name, address, phone, email)
            VALUES ($1, $2, $3, $4) RETURNING patronsID;
        ";

        // Execute the query with parameters bound to the placeholders
        $result = pg_query_params($db_conn, $query, array($name, $address, $phone, $email));

        // Check if the query was successful
        if ($result) {
            // Get the newly inserted patron ID
            $new_patron_id = pg_fetch_result($result, 0, 'patronsID');
            echo "New patron added successfully with ID: $new_patron_id<br>";
        } else {
            echo "Error adding patron: " . pg_last_error($db_conn) . "<br>";
        }
    }
}

// Close the database connection
pg_close($db_conn);
?>
