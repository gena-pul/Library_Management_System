<?php
// Enable error reporting to display any PHP errors
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection credentials
$host = "localhost";            // Database host
$dbname = "lms_database";       // Database name
$user = "postgres";             // Database user
$password = "191217Azena";      // Database password

// Attempt to connect to PostgreSQL
$db_conn = pg_connect("host=$host dbname=$dbname user=$user password=$password");

// Check if the connection was successful
if (!$db_conn) {
    die("Connection failed: " . pg_last_error());
}

// Query to get the most popular book (highest borrow count) based on the count of loans
$query = "
    SELECT b.Title, COUNT(l.loansid) AS borrowCount
    FROM loans l
    JOIN books b ON l.bookid = b.bookid
    GROUP BY b.Title
    ORDER BY borrowCount DESC
    LIMIT 1;  -- Fetch only the most popular book
";

$result = pg_query($db_conn, $query);

// Check if the query was successful
if (!$result) {
    echo "Error executing query: " . pg_last_error($db_conn);
} else {
    // Display the results in a table with borders
    echo "<h2>Most Popular Book</h2>";
    echo "<table border='1' style='border-collapse: collapse; width: 50%;'>";
    echo "<tr><th style='padding: 10px; text-align: left;'>Book Title</th><th style='padding: 10px; text-align: left;'>Borrow Count</th></tr>";

    // Loop through the query results and display them
    while ($row = pg_fetch_assoc($result)) {
        // Use lowercase column names as returned in the query result
        $bookTitle = isset($row['title']) ? htmlspecialchars($row['title']) : 'No title available';
        $borrowCount = isset($row['borrowcount']) ? htmlspecialchars($row['borrowcount']) : '0';

        echo "<tr>
                <td style='padding: 10px;'>$bookTitle</td>
                <td style='padding: 10px;'>$borrowCount</td>
              </tr>";
    }

    echo "</table>";
}

// Close the database connection
pg_close($db_conn);
?>
