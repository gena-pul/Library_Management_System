<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection
$host = "localhost";
$port = "5432";
$dbname = "lms_database";
$user = "postgres";
$password = "191217Azena";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Error: Unable to connect to the database.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data safely
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $author_name = isset($_POST['author_name']) ? $_POST['author_name'] : '';
    $nationality = isset($_POST['nationality']) ? $_POST['nationality'] : '';
    $birthdate = isset($_POST['birthdate']) ? $_POST['birthdate'] : '';
    $author_id = isset($_POST['author_id']) ? $_POST['author_id'] : ''; // For update or delete actions

    // Check for missing fields (for add action)
    if ($action == 'add' && (empty($author_name) || empty($nationality) || empty($birthdate))) {
        echo "Please fill in all fields.";
        exit;
    }

    // Handle 'add' action - inserting a new author
    if ($action == 'add') {
        $query = "INSERT INTO Authors (Name, Nationality, Birthdate) VALUES ($1, $2, $3)";
        $result = pg_query_params($conn, $query, array($author_name, $nationality, $birthdate));

        if ($result) {
            echo "Author added successfully!";
        } else {
            echo "Error in adding author: " . pg_last_error($conn);
        }
    }

    // Handle 'update' action - updating an existing author
    if ($action == 'update' && !empty($author_id)) {
        $query = "UPDATE Authors SET Name = $1, Nationality = $2, Birthdate = $3 WHERE authorsID = $4";
        $result = pg_query_params($conn, $query, array($author_name, $nationality, $birthdate, $author_id));

        if ($result) {
            echo "Author updated successfully!";
        } else {
            echo "Error in updating author: " . pg_last_error($conn);
        }
    }

    // Handle 'delete' action - deleting an author
    if ($action == 'delete' && !empty($author_id)) {
        $query = "DELETE FROM Authors WHERE authorsID = $1";
        $result = pg_query_params($conn, $query, array($author_id));

        if ($result) {
            echo "Author deleted successfully!";
        } else {
            echo "Error in deleting author: " . pg_last_error($conn);
        }
    }

} else {
    echo "Form not submitted correctly.";
}

// Close the connection
pg_close($conn);
?>
