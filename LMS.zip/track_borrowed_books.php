<?php
// Enable error reporting to display any PHP errors
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection credentials
$host = "localhost";            // Database host
$dbname = "lms_database";       // Database name
$user = "postgres";             // Database user
$password = "191217Azena";      // Database password

// Attempt to connect to PostgreSQL
$db_conn = pg_connect("host=$host dbname=$dbname user=$user password=$password");

// Check if the connection was successful
if (!$db_conn) {
    die("Connection failed: " . pg_last_error());
}

// Get the patron ID from POST request
$patron_id = isset($_POST['patron_id']) ? (int)$_POST['patron_id'] : 0;

// If patron_id is invalid or empty, display an error
if ($patron_id <= 0) {
    echo "Invalid Patron ID.";
    exit();
}

// SQL query to get borrowed books by patron ID
$query = "
    SELECT 
        b.title AS book_title,
        l.loanDate AS loan_date,
        l.dueDate AS due_date,
        CASE 
            WHEN l.returnDate IS NULL THEN 'Overdue' 
            ELSE 'Returned' 
        END AS status
    FROM 
        loans l
    JOIN 
        books b ON l.bookID = b.bookID
    WHERE 
        l.patronID = $patron_id;
";

// Execute the query
$result = pg_query($db_conn, $query);

// Check if the query was successful
if (!$result) {
    echo "Error executing query: " . pg_last_error($db_conn);
} else {
    // Display the results in a styled table format
    echo "<h2>Borrowed Books for Patron ID: $patron_id</h2>";
    echo "<table border='1' style='border-collapse: collapse; width: 80%; margin: 20px auto;'>
            <thead>
                <tr>
                    <th style='padding: 10px; text-align: left;'>Book Title</th>
                    <th style='padding: 10px; text-align: left;'>Loan Date</th>
                    <th style='padding: 10px; text-align: left;'>Due Date</th>
                    <th style='padding: 10px; text-align: left;'>Status</th>
                </tr>
            </thead>
            <tbody>";

    // Fetch and display the rows of borrowed books
    while ($row = pg_fetch_assoc($result)) {
        echo "<tr>
                <td style='padding: 10px;'>" . htmlspecialchars($row['book_title']) . "</td>
                <td style='padding: 10px;'>" . htmlspecialchars($row['loan_date']) . "</td>
                <td style='padding: 10px;'>" . htmlspecialchars($row['due_date']) . "</td>
                <td style='padding: 10px;'>" . htmlspecialchars($row['status']) . "</td>
              </tr>";
    }

    echo "</tbody></table>";
}

// Close the database connection
pg_close($db_conn);
?>
